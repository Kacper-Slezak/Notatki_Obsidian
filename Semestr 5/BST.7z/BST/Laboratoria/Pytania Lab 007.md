## Lab 07: Bluetooth

1. Wyjaśnij czym jest _pikosieć_ (piconet), podaj jej częstotliwość, szerokość kanału i liczbę kanałów.
    
2. Czy standardy 802.11g/a zakłócają Bluetooth?.
    
3. Jaki mechanizm minimalizuje interferencje w Bluetooth? Opisz go.
    
4. Z jakimi standardami Wi-Fi pokrywa się pasmo BT?.
    
5. Co to są profile BT? Do czego wykorzystywany jest profil SPP?.
    
6. Jaka warstwa znajduje się najniżej w stosie Bluetooth?.
    
7. Wymień 2 warstwy nad HCI.
    
8. Między jakimi warstwami interfejs stanowi HCI?.
    
9. Czy w topologii Bluetooth można być Master i Slave jednocześnie?.
    
10. Czy urządzenie może być podłączone jako slave z dwoma masterami?.
    
11. Wyjaśnij pojęcie _Scatternet_.
    
12. Wyjaśnij pojęcie _Parked Slave_.
    
13. Jaka modulacja działa w Bluetooth?.
    



---

Co to spp, jakie pasmo na Bt i z jakimi standardami wifi się to pokrywa
Co to pikosieć, Częstotliwość szerokość kanału i liczba kanałów
Napisać co to scatternet i czy 802.11a zakłóca bluetooth
Lab7 1. Co to PAN 2. Mechanizm ktory minimalizuje interferencje (nazwac i opisac)
Lab 7: 1. Czym sa profile Bluetooth 2. Czy urządzenia standardu IEEE 802.11g zakłócaja urządzenia Bluetooth? Odpowiedź uzasadnij
9:45 Lab 7. 2 warstwy nad hci Jaka modulacja W Bluetooth, uzasadnij
Lab7 11:30 1. Do czego na ćwiczeniu wykorzystywany jest profil SPP? 2. W jakim paśmie częstotliwości pracuje bluetooth? Z jakimi innymi standardami współdzieli to pasmo?
Lab7 Czy 802.11 zakloca Warstwy ktore sie komunikuja z L2CAP
Lab 7 9:45 1. Czy urzadzenie bluetooth moze być polączone jako slave z dwoma masterami? 2. Najnizsza warstwa w stosie protokolow bluetooth
lab 7 13:15 szerokość kanałów, na jakiej cz bluetooth, ile jest kanalow czym jest parked slave


## Lab 7:

- Wyjaśnij czym jest pikosieć (ang. piconet)? 
    
- Jaka warstwa znajduje się najniżej w stosie protokołów Bluetooth? 
    
- Czy transmisje działające w standardzie 802.11g są w stanie zakłócić działanie transmisjii działających z użyciem Bluetooth? Odpowiedz uzasadnij
    
- Co to są profile?
    
- Wyjaśnij skrót SPP
    
- Wyjaśnij skrót FTP
    
- Jakie standardy WiFi mogą interferować z Bluetooth?
    
- Czy w topologii bluetooth można pełnić rolę master i slave jednocześnie?
    
- W jakich częstotliwościach działa bt i z jakimi standardami wifi to się pokrywa?
    
- Co to jest parked slave?
    
- Jaka modulacja działa w bluetooth?
    
- między jakimi warstwami połączenie stanowi interfejs HCI?
    
- Jaki jest mechanizm zapobiegania interferencjom, opisz
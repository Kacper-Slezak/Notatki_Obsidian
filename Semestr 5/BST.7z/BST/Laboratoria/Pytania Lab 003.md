
## Lab 03: WEP i Ataki (Aircrack-ng)
1. Wyjaśnij pojęcie ataku _Zero Knowledge_.
    
2. Wyjaśnij do czego służy narzędzie Kismet.
    
3. Wyjaśnij pojęcie _Packet Injection_ (wstrzykiwanie pakietów).
    
4. Do czego używa się _airodump-ng_?.
    
5. Do czego służy _airbase-ng_?.
    
6. Wyjaśnij co to jest _Airplay-ng_.
    
7. Jak długi jest IV (Initialization Vector), z czego się składa i jak go odczytać/rozkodować z ramki?.
    
8. Na czym polega _replay attack_?.
    
9. Opisz schemat kodowania WEP oraz narysuj schemat blokowy dekodowania ramki.
    


---

Jak długo jest iv i z czego się składa Do czego służy airbase-ng
Airplay -ng co to I schemat kodowania wep
Co robi airdump i na czym polega replay attack
Jak odczytać wektor IV Schemat blokowy dekodowania ramki wep
Laboratorium 3
Wejściówka
● Grupa 1
○ Nazwy ataków gdy wi-fi nie jest w zasięgu - Cafe Latte, Hirte
○ Czym jest atak zero knowledge - że się nie ma wiedzy o niczym, obviously
● Grupa 2
○ Do czego służy Kismet - do zbierania info o SSID, BSSID, kanału sieci,
adresów MAC
○ Packet Injection - wstrzykujemy pakiety do sieci
● Grupa 3
○ Jak rozkodować IV z ramki MAC
○ Do czego używa się airodump-ng - zrzucanie pakietów z sieci do pliku
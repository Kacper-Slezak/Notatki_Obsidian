
## Lab 08: RADIUS i 802.1x

1. Czym jest PEAP? Wypisz główne zalety i wady.
    
2. Jakie są elementy architektury RADIUS?.
    
3. Wyjaśnij pojęcie EAP-TLS oraz podaj jego wady i zalety.
    
4. Co to jest _Authenticator_ i jaką funkcję pełni w RADIUS?.
    
5. Jakie urządzenia mogą pełnić rolę Authenticatora?.
    
6. Wyjaśnij pojęcie _Supplicant_ i jaką pełni funkcję.
    
7. Wyjaśnij pojęcie MSCHAPv2.
    
8. Rozwiń skrót AAA.
    
9. Rozwiń skrót EAPOL.
    
10. W jakiej warstwie działa 802.1x i do czego służy?.
    
11. Do czego służy _hostapd-wpe_?.
    




---

1. Czym jest PEAP? Wypisz główne zalety i wady 2. Jakie są elementy architektury RADIUS?
2. jak dziala eap tls wady zalety
i jaka funkcje supplicant w radiusie

lab8 co oznacza i gdzie występuje EAPOL wyjaśnij co to authenticator i jaka funkcje pełni w RADIUS
Co to eap-md5 Jakie urządzenie w labie pełni rolę authenticatora
Lab 8 o 9⁴⁵ Dlaczego peap jest najbardziej powszechny Co to jest authenticator i jakie urządzenia mogą nim byc
Czym jest LEAP, zalety i wady. Czym jest standard 802.1x i do czego służy.
Lab 8 Rozwiń skrót AAA, co to znaczy? A drugie nie pamiętam jakieś dziwne było

## Lab 8:

- Czym jest PEAP? Wypisz główne zalety i wady i Jakie są elementy architektury RADIUS?
    
- Skrót RADIUS i “W jakiej warstwie działa 802.1x czy coś w tym stylu”
    
- Wyjaśnij skrót EAPOL i Wyjaśnij co to jest authenticator i jaką funkcje pełni w architekturze RADIUS?
    
- EAP-TLS co to, wady, zalety i Supplicant, co to, funkcja
    
- Jaką rolę pełni switch w komunikacji między supplicantem, a ASem
    
- Skrót AAA co znaczy 
    
- Jaką rolę pełni authenticator w architekturze radius?
    
- Dlaczego peap jest bezpieczny?jakie protokoły zapewniają najmniejszy poziom bezpieczeństwa, dlaczego
    
- wyjaśnij co to jest authenticator i jakie urządzenia mogą pełnić tę rolę
    
- MSCHOPv2 i Co to jest Supplicant.
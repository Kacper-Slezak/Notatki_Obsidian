
## Lab 10: High Throughput (802.11n/ac) i Ad-Hoc

1. Jakie ulepszenia wprowadzono w 802.11n?.
    
2. Jakie szerokości pasma może mieć 802.11ac?.
    
3. Czy urządzenia 802.11a i 802.11ac mogą działać razem/w tym samym kanale? Odpowiedź uzasadnij.
    
4. Co to jest OFDM i w jakich standardach jest wykorzystywany?.
    
5. Czy OFDM i MIMO mogą być używane jednocześnie (np. w Ad-Hoc)?.
    
6. Czym charakteryzuje się sieć w trybie Ad-Hoc?.
    
7. Czym jest IBSS i czym różni się od BSS?.
    
8. Czy w Ad-Hoc mogą komunikować się urządzenia DSSS (80MHz) i OFDM?.
    
9. Kiedy zalecane jest włączenie RTS/CTS w sieciach Ad-Hoc?.
    
10. W jakim przypadku transmisja TCP może być wolniejsza od UDP w sieci radiowej?.
    
11. Wymień 3 topologie Wi-Fi.
    
12. Jaki jest wpływ _Fragmentation Threshold_ na działanie sieci?.
    
13. Wyjaśnij zjawisko anomalii wydajności.

---


Jakie szerokości może mieć pasmo w 802.11ac Wymień 3 topologie używane w sieciach wi-fi
Lab 10 tcp vs udp W throughputcie Oraz wytłumaczyć czym jest ibss oraz bss
1.Ulepszenia wprowadzone w 802.11n 2.Czym charakteryzuje sie ad-hoc
Lab 10 1. Czym jest OFDM i w jakich standardach jest wykorzystywany 2. Czy w trybie ad-hoc mogą się komunikować urządzenia używające techniki DSSS na kanale o szerokości 80MHz
Lab10: 1. Czy w jednej sieci ad-hoc mogą być jednocześnie wykorzystywane DSSS i OFDM? 2. Kiedy jest zalecane włączenie mechanizmu RTS/CTS w sieciach Ad-hoc
Lab 10 1.czym jest dsss i w których standardach jest wykorzystywany 2. Czy mimo i ofdm mogą być wykorzystywane równocześnie odpowiedź uzasadnij
Co to dsss i w jakich standardach jest używany? Czy ofdm i mimo mogą być używane jednocześnie w sieciach ad-hoc? Uzasadnij
Lab 10 Czy karty sieciowe w standardach 802.11/a i 802.11/ac moga działać razem, i dlaczego Zjawisko anomalii wydajnosco
lab 10 ad-hoc cechy fragmentation threshold
Lab10 11.30 1. Czym jest OFDM i w jakich standardach jest wykorzystywany? 2. Czy urządzenia 802.11n i 802.11ac mogą pracować w tym samym kanale radiowym?
|10 lab Czy urządzenia w standardach a i ac mogą działać razem odpowiedź uzasadnij Jaki jest wpływ fragmentation thresholf na działanie sieci


## Lab 10:

- Czym jest IBSS i czym się różni od BSS?
    
- W jakim przypadku transmisja TCP może być wolniejsza od transmisji UDP?
    

- TCP traktuje utratę pakietu jako przeciążenie sieci ale w sieciach radiowych może to wynikać po prostu z kolizji i to wcale nie oznacza przeciążenia więc TCP obniżyło prędkość transmisji mimo że można było utrzymać wysoką.
    

- Kiedy i dlaczego działanie protokołów TCP i UDP wpływa na przepustowość w sieci?
    
- Co to jest OFDM i w jakich standardach 802.11 jest używany?  - w 802.11 a/g
    
- Wymień 3 typologie WIFI 
    
- co to OFDM, w jakich standardach się znajduje.
    
- Czy OFDM i MIMO mogą być używane w jednej sieci?
    

- Nie wiem czy dobrze: TAK, na przyklad 802.11 n korzysta z MIMO i OFDM
    

- Co charakteryzuje sieć WLAN działającą w trybie ad-hoc?
    

- To jest praktycznie to samo pytanie inaczej sformulowane o to co to jest IBSS?


## Lab 02: Analiza ramek i Wireshark

1. Jaki jest filtr w Wiresharku do filtrowania po BSSID?.
    
2. Podaj komendę/filtr, dzięki której możemy wyświetlić ramki zawierające konkretny adres źródłowy.
    
3. Wymień cztery rodzaje ramek kontrolnych (np. RTS, CTS, ACK, PS-Poll).
    
4. Wymień 6 rodzajów ramek zarządzających.
    
5. Ile jest pól adresowych w nagłówku ramki MAC?.
    
6. Co znajduje się na początku ramki PLCP?.
    
7. Jakiego trybu karty sieciowej użyć, żeby słuchać wszystkich pakietów?.
    


---
Bst gr 2 - ile jest pol adresowych w naglowku MAC - jaki jest filtr w wiresharku do filtrowania bssid
wymień 6 rodzajów ramek zarządzających - podaj komendę do wiresharka, dzięki której możemy wyświetlić ramki zawierające adres źródłowy


Wejściówka
● Grupa 1
○ Jakaś reguła z wiresharka (filtrowanie)
○ Wymień cztery ramki kontrolne - RTS, CTS, ACK, PS-Poll
● Grupa 2
○ Ile pól adresowych ma ramka MAC (cztery)
○ Filtr wiresharka do BSSID (wlan.bssid == AP_radio_MAC_address)
● Grupa 3
○ Co jest na początku ramki PLCP (preambuła)
○ Jakiego trybu karty sieciowej użyć, żeby słuchać wszystkich pakietów
(monitor)
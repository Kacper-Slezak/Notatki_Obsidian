1. 802.11c
Standard ten definiuje procedury operacyjne dla mostów (bridge) w sieciach bezprzewodowych. Dodaje podsekcję do standardu MAC, aby zapewnić poprawną współpracę mostów z ramkami 802.11.
Jest on istotny głównie dla **producentów sprzętu** (tworzących punkty dostępowe), a nie dla instalatorów czy użytkowników. Kluczową zasadą jest to, że most nie może łączyć się z siecią w trybie **Ad-Hoc (IBSS)**

2. 802.11d

- Dostosowuje ramka i różne kanały itp. do prawa konkretnego kraju 
- Np. moc, kanał
- Taka globalna harmonizacja
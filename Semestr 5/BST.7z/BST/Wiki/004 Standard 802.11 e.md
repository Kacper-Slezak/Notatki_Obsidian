# Standard wprowadzający QoS 
## HCF

# Funkcje aktywacji 

- Liniowa h(x) = x 
- Sigmoid h(x)  = 1/ 1+e^x
- Tanh = h(x) = 2/(1 + e^-2x ) - 1
- reLU dla x >=0 , x dla x < 0, 0
- softmax = wielowymiarowy sigmoid 

	Precyzja - co oznaczyliśmy jako anomalię, faktycznie nią jest?
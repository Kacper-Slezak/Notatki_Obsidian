# Ataki adwersarialne

- wykorzystują specjalnie spreparowane dane wejściowe 
- wywodzą się z modeli rozpoznawania obrazów i w tym przypadku
 najbardziej efektownie działają
- model jest nauczony a atakujący bierze swoje próbki i może wpuszczać dane do modelu
- 
 
#  Opis

- Algorytm widzi dane i zbiera doświadczenie
- Agent podejmuje akcje i dostaje nagrodę albo karę

## Przykład: 

- **Agent** podejmuję decyzje na podstawie stanu środowiska
- **Środowisko** to model tego co może się wydarzyć 
- **Problem** agenta:
	- wybrać odpowiednią akcje
	- w określonym obserwowanym stanie 
	- w celu uzyskania nagrody

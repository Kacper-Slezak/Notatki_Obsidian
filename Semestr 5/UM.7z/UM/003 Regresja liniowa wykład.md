1. hipoteza:
h(x) = θ0· x0 + θ1· x1 + … + θn· xn
2. funkcja kosztu:
![[Pasted image 20260123112555.png]]
3. gradient descent:
![[Pasted image 20260123112630.png]]
